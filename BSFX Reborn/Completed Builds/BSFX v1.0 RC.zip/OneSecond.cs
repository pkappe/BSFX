﻿using System;
using System.Windows.Forms;

namespace $safeprojectname$
{
	public partial class $safeprojectname$ : Form
	{
		// One second timer for Interval Remaining
		private void oneSecTimer_Tick_1(object sender, EventArgs e)
		{
			try
			{
				intervalLeft = intervalLeft - 1;
				TimeSpan t = TimeSpan.FromSeconds(intervalLeft);
				string answer = string.Format("{0:D2}h:{1:D2}m:{2:D2}s",
								t.Hours,
								t.Minutes,
								t.Seconds);

				intervalLeftBox.Text = answer;
			}
			catch (Exception oneErr)
			{
				Console.WriteLine(oneErr);
			}
		}
	}
}
