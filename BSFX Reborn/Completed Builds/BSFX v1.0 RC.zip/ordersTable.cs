﻿using fxcore2;
using System;
using System.ComponentModel;
using System.Threading;
using System.Windows.Forms;

namespace $safeprojectname$
{
	public partial class $safeprojectname$ : Form
	{
		void ordersTable_RowChanged(object sender, RowEventArgs e)
		{
			
		}
	}
}
